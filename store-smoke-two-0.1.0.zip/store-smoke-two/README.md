# Store Smoke Test 2

A harmless second listing to verify multiple catalog cards and selected-widget icon previews.
