# Store Smoke Test

A tiny, harmless test widget for verifying the Widget Store catalog and package distribution. It displays a confirmation message only.
